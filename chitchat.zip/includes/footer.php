<nav class='navbar-fixed-bottom'>
<footer>
    Copyright <i class='fa fa-copyright'></i> Bjorn Keyser 2016 - 
    <?php echo date('Y');?>. All Rights Reserved
  </footer>
  </nav>